#include "NetgenGeometricRefit.hpp"

#ifdef HAVE_NETGEN

#include "netgen_meshing.hpp"

#include <limits>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <unordered_map>
#include <vector>

namespace ng = netgen;

namespace {

// Gauss-Legendre rule on (0,1).
void gauss_rule(int n, std::vector<double> & x, std::vector<double> & w)
{
  x.resize(n);
  w.resize(n);
  for (int i = 0; i < n; i++) {
    const double pi = 3.14159265358979323846;
    double z = std::cos(pi * (i + 0.75) / (n + 0.5));
    for (int it = 0; it < 100; it++) {
      double p0 = 1, p1 = z;
      for (int k = 2; k <= n; k++) {
        double p2 = ((2 * k - 1) * z * p1 - (k - 1) * p0) / k;
        p0 = p1;
        p1 = p2;
      }
      double dp = n * (z * p1 - p0) / (z * z - 1);
      double dz = p1 / dp;
      z -= dz;
      if (std::fabs(dz) < 1e-16) break;
    }
    double p0 = 1, p1 = z;
    for (int k = 2; k <= n; k++) {
      double p2 = ((2 * k - 1) * z * p1 - (k - 1) * p0) / k;
      p0 = p1;
      p1 = p2;
    }
    double dp = n * (z * p1 - p0) / (z * z - 1);
    x[i] = 0.5 * (1 - z);
    w[i] = 1.0 / ((1 - z * z) * dp * dp);
  }
}

// Least-squares solution of min |A x - b| for a row-major m x n matrix
// (m >= n) by Householder QR, in place; x is returned in b[0..n).  QR works
// on A itself: forming the normal equations A^T A squares the condition
// number, which reaches 1e14 for order-5 face bubbles and leaves the step
// with no correct digits.  Returns false if A is rank deficient.
bool lstsq_qr(std::vector<double> & A, std::vector<double> & b, int m, int n)
{
  for (int c = 0; c < n; c++) {
    double norm = 0;
    for (int r = c; r < m; r++) norm += A[r * n + c] * A[r * n + c];
    norm = std::sqrt(norm);
    if (!(norm > 0)) return false;
    const double alpha = A[c * n + c] > 0 ? -norm : norm;
    // v = a_c - alpha e_c, stored in column c below the diagonal.
    A[c * n + c] -= alpha;
    double vv = 0;
    for (int r = c; r < m; r++) vv += A[r * n + c] * A[r * n + c];
    if (vv > 0) {
      for (int k = c + 1; k < n; k++) {
        double s = 0;
        for (int r = c; r < m; r++) s += A[r * n + c] * A[r * n + k];
        s *= 2 / vv;
        for (int r = c; r < m; r++) A[r * n + k] -= s * A[r * n + c];
      }
      double s = 0;
      for (int r = c; r < m; r++) s += A[r * n + c] * b[r];
      s *= 2 / vv;
      for (int r = c; r < m; r++) b[r] -= s * A[r * n + c];
    }
    A[c * n + c] = alpha;   // R's diagonal
  }
  for (int r = n - 1; r >= 0; r--) {
    double s = b[r];
    for (int k = r + 1; k < n; k++) s -= A[r * n + k] * b[k];
    b[r] = s / A[r * n + r];
  }
  return true;
}

// Reference coordinates of the vertices of a linear surface element, in
// Netgen's convention (TRIG: lambda = {x, y, 1-x-y}; QUAD: bilinear).
std::array<double, 2> vertex_ref(ng::ELEMENT_TYPE type, int v)
{
  static const double trig[3][2] = {{1, 0}, {0, 1}, {0, 0}};
  static const double quad[4][2] = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};
  if (type == ng::TRIG) return {trig[v][0], trig[v][1]};
  return {quad[v][0], quad[v][1]};
}

// Linear shape weights of the element vertices at a reference point, used
// to interpolate the vertices' surface parameters into a projection hint.
void vertex_weights(ng::ELEMENT_TYPE type, double a, double b, double * lam)
{
  if (type == ng::TRIG) {
    lam[0] = a;
    lam[1] = b;
    lam[2] = 1 - a - b;
  } else {
    lam[0] = (1 - a) * (1 - b);
    lam[1] = a * (1 - b);
    lam[2] = a * b;
    lam[3] = (1 - a) * b;
  }
}

// One curved entity (edge or face) whose coefficients are refitted.
struct Entity
{
  ng::SurfaceElementIndex sei;   // surface element used for evaluation
  int surfnr = -1;               // surface for normal-distance entities
  bool on_curve = false;         // distance to a geometric curve instead
  int surfnr1 = -1, surfnr2 = -1;   // curve: 1-based face descriptors
  int edgenr = -1;                  // curve: geometric edge number
  std::vector<std::array<double, 2>> fit_ref, check_ref;  // reference points
  std::vector<double> fit_w;
  // Optional per-sample surface element and surface (-1: the entity's own
  // geometry).  An order-2 edge also samples the interiors of adjacent
  // triangles, whose shape it alone determines.
  std::vector<ng::SurfaceElementIndex> fit_sei, check_sei;
  std::vector<int> fit_surf, check_surf;
  ng::SurfaceElementIndex fit_el(size_t j) const { return fit_sei.empty() ? sei : fit_sei[j]; }
  ng::SurfaceElementIndex check_el(size_t j) const { return check_sei.empty() ? sei : check_sei[j]; }
  int fit_sn(size_t j) const { return fit_surf.empty() ? -1 : fit_surf[j]; }
  int check_sn(size_t j) const { return check_surf.empty() ? -1 : check_surf[j]; }
  // Optional acceptance limits: check sample j belongs to group
  // check_group[j], whose max distance may not exceed group_limit[group]
  // (the distance with Netgen's coefficients).  Group 0 is the edge itself.
  std::vector<int> check_group;
  std::vector<double> group_limit;
  double scale = 1;              // characteristic length (edge length)
  // Directions in which each coefficient may change.  An edge inside a
  // surface can slide laterally without changing its distance to the
  // surface; that exact null direction is excluded, leaving the chord
  // direction and the surface normal.  Empty means all three axes.
  std::vector<ng::Vec<3>> free_dirs;
  // Volume elements that share the entity; their Jacobians must stay valid.
  std::vector<ng::ElementIndex> volumes;
};

// Interior sample points of a volume element's reference domain.
const std::vector<ng::Point<3>> & volume_ref_points(ng::ELEMENT_TYPE type)
{
  static std::unordered_map<int, std::vector<ng::Point<3>>> cache;
  auto it = cache.find(int(type));
  if (it != cache.end()) return it->second;
  std::vector<ng::Point<3>> pts;
  const int m = 5;
  for (int i = 0; i < m; i++)
    for (int j = 0; j < m; j++)
      for (int k = 0; k < m; k++) {
        double a = (i + 0.5) / m, b = (j + 0.5) / m, c = (k + 0.5) / m;
        bool inside = true;
        switch (type) {
          case ng::TET: inside = a + b + c < 1; break;
          case ng::PRISM: inside = a + b < 1; break;
          case ng::PYRAMID: inside = a < 1 - c && b < 1 - c; break;
          default: break;
        }
        if (inside) pts.emplace_back(a, b, c);
      }
  return cache.emplace(int(type), std::move(pts)).first->second;
}

// Volume elements containing all the given vertices.
std::vector<ng::ElementIndex> shared_volumes(const ng::MeshTopology & top,
                                             const std::vector<ng::PointIndex> & verts)
{
  std::vector<ng::ElementIndex> out;
  if (verts.empty()) return out;
  for (auto ei : top.GetVertexElements(verts[0])) {
    bool all = true;
    for (size_t k = 1; k < verts.size() && all; k++) {
      bool found = false;
      for (auto ej : top.GetVertexElements(verts[k]))
        if (ej == ei) { found = true; break; }
      all = found;
    }
    if (all) out.push_back(ei);
  }
  return out;
}

struct Refitter
{
  ng::Mesh & mesh;
  ng::CurvedElements & curved;
  const ng::NetgenGeometry & geo;

  Refitter(ng::Mesh & m)
    : mesh(m), curved(m.GetCurvedElements()), geo(*m.GetGeometry()) {}

  ng::Point<3> eval(ng::SurfaceElementIndex sei, const std::array<double, 2> & r)
  {
    ng::Point<3> x;
    curved.CalcSurfaceTransformation(ng::Point<2>(r[0], r[1]), sei, x);
    return x;
  }

  // Closest point on the geometry and the unit directions whose distance
  // components are minimised (the surface normal, or the plane normal to
  // a curve).  Returns false when the projection is not trustworthy.
  bool project(const Entity & e, const std::array<double, 2> & r,
               const ng::Point<3> & x, ng::Point<3> & q,
               std::vector<ng::Vec<3>> & dirs)
  {
    return project(e, e.sei, -1, r, x, q, dirs);
  }

  // sei: the surface element r refers to; surf >= 0 projects onto that
  // surface instead of the entity's own curve or surface.
  bool project(const Entity & e, ng::SurfaceElementIndex sei, int surf,
               const std::array<double, 2> & r, const ng::Point<3> & x,
               ng::Point<3> & q, std::vector<ng::Vec<3>> & dirs)
  {
    const auto el = mesh[sei];
    const int surfnr = surf >= 0 ? surf : e.surfnr;
    q = x;
    dirs.clear();
    if (e.on_curve && surf < 0) {
      ng::EdgePointGeomInfo egi;
      geo.ProjectPointEdge(e.surfnr1, e.surfnr2, q, &egi, e.edgenr);
      ng::Vec<3> t = geo.GetTangent(q, e.surfnr1, e.surfnr2, egi, e.edgenr);
      double tl = t.Length();
      if (!(tl > 0)) return false;
      t /= tl;
      // Orthonormal basis of the plane normal to the curve tangent.
      ng::Vec<3> a = std::fabs(t(0)) < 0.9 ? ng::Vec<3>(1, 0, 0) : ng::Vec<3>(0, 1, 0);
      ng::Vec<3> n1 = a - (a * t) * t;
      n1 /= n1.Length();
      ng::Vec<3> n2 = ng::Cross(t, n1);
      dirs.push_back(n1);
      dirs.push_back(n2);
    } else {
      double lam[4];
      vertex_weights(el.GetType(), r[0], r[1], lam);
      ng::PointGeomInfo gi = el.GeomInfoPi(1);
      gi.u = gi.v = 0;
      for (int k = 0; k < el.GetNP(); k++) {
        gi.u += lam[k] * el.GeomInfoPi(k + 1).u;
        gi.v += lam[k] * el.GeomInfoPi(k + 1).v;
      }
      if (!geo.ProjectPointGI(surfnr, q, gi)) return false;
      ng::Vec<3> n = geo.GetNormal(surfnr, q, &gi);
      double nl = n.Length();
      if (!(nl > 0)) return false;
      dirs.push_back((1.0 / nl) * n);
    }
    // A projection that jumps by a sizeable fraction of the entity is a
    // wrong-branch result, not a curvature offset.
    return ng::Dist(x, q) <= 0.5 * e.scale;
  }

  // Max sampled distance to the geometry, or -1 if a projection failed.
  double max_distance(const Entity & e)
  {
    double d = 0;
    ng::Point<3> q;
    std::vector<ng::Vec<3>> dirs;
    for (size_t j = 0; j < e.check_ref.size(); j++) {
      const auto & r = e.check_ref[j];
      ng::Point<3> x = eval(e.check_el(j), r);
      if (!project(e, e.check_el(j), e.check_sn(j), r, x, q, dirs)) return -1;
      d = std::max(d, ng::Dist(x, q));
    }
    return d;
  }

  // Max sampled distance per check group, or empty if a projection failed.
  std::vector<double> group_max(const Entity & e)
  {
    std::vector<double> g(e.group_limit.size(), 0.0);
    ng::Point<3> q;
    std::vector<ng::Vec<3>> dirs;
    for (size_t j = 0; j < e.check_ref.size(); j++) {
      ng::Point<3> x = eval(e.check_el(j), e.check_ref[j]);
      if (!project(e, e.check_el(j), e.check_sn(j), e.check_ref[j], x, q, dirs)) return {};
      double &m = g[e.check_group[j]];
      m = std::max(m, ng::Dist(x, q));
    }
    return g;
  }

  // Surface area element |dx/dxi x dx/deta| at the entity's sample points.
  std::vector<double> area_samples(const Entity & e)
  {
    std::vector<double> a;
    for (int which = 0; which < 2; which++)
      for (size_t j = 0; j < (which ? e.fit_ref : e.check_ref).size(); j++) {
        const auto & r = (which ? e.fit_ref : e.check_ref)[j];
        const auto sei = which ? e.fit_el(j) : e.check_el(j);
        ng::Point<3> x;
        ng::Mat<3, 2> jac;
        curved.CalcSurfaceTransformation(ng::Point<2>(r[0], r[1]), sei, x, jac);
        ng::Vec<3> c0(jac(0, 0), jac(1, 0), jac(2, 0)), c1(jac(0, 1), jac(1, 1), jac(2, 1));
        a.push_back(ng::Cross(c0, c1).Length());
      }
    return a;
  }

  // Jacobian determinants of the adjacent volume elements at interior
  // sample points (empty for a surface-only mesh).  Uses Netgen's
  // multi-point transformation, the path NGSolve assembles with: the scalar
  // CalcElementTransformation ignores hex quad-face coefficients and leaves
  // their derivative rows uninitialised.
  std::vector<double> volume_det_samples(const Entity & e)
  {
    std::vector<double> d;
    for (auto ei : e.volumes)
      for (const auto & p : volume_ref_points(mesh[ei].GetType())) {
        double xi[3] = {p(0), p(1), p(2)}, x[3], j[9];
        curved.CalcMultiPointElementTransformation(ei, 1, xi, 3, x, 3, j, 9);
        d.push_back(j[0] * (j[4] * j[8] - j[5] * j[7])
                  - j[1] * (j[3] * j[8] - j[5] * j[6])
                  + j[2] * (j[3] * j[7] - j[4] * j[6]));
      }
    return d;
  }

  // True when every sample keeps its sign and changes by at most a factor
  // of two.  Netgen elements may carry a negative determinant by vertex
  // order, so the comparison is pointwise against the same sample.
  static bool within_factor_two(const std::vector<double> & before,
                                const std::vector<double> & after)
  {
    for (size_t i = 0; i < before.size(); i++) {
      // A sample that was already zero or non-finite cannot be compared.
      if (before[i] == 0 || !std::isfinite(before[i])) continue;
      double r = after[i] / before[i];
      if (!(r >= 0.5 && r <= 2.0)) return false;
    }
    return true;
  }

  // Distance-minimising refit of the `n` coefficient vectors at `coef`.
  // Returns +1 accepted, 0 unchanged (no gain), -1 failed.
  int refit(const Entity & e, ng::Vec<3> * coef, int n,
            double & before, double & after)
  {
    const int np = (int)e.fit_ref.size();
    const int nu = 3 * n;
    std::vector<ng::Vec<3>> saved(coef, coef + n);

    before = max_distance(e);
    if (before < 0) return -1;
    const std::vector<double> area0 = area_samples(e);
    const std::vector<double> det0 = volume_det_samples(e);
    // Trust region: one step, and the total change, stay a fraction of the
    // entity size.  The distance cannot see a slide along the surface, so
    // without a bound an ill-conditioned step can wrap an element around it.
    const double max_step = 0.1 * e.scale, max_change = 0.25 * e.scale;

    // Basis values: the mapping is affine in the coefficients.
    std::vector<ng::Point<3>> x0(np);
    for (int j = 0; j < np; j++) x0[j] = eval(e.fit_el(j), e.fit_ref[j]);
    std::vector<double> phi(n * np);
    for (int k = 0; k < n; k++) {
      coef[k](0) += 1.0;
      for (int j = 0; j < np; j++)
        phi[k * np + j] = eval(e.fit_el(j), e.fit_ref[j])(0) - x0[j](0);
      coef[k](0) -= 1.0;
    }

    // Weighted normal-distance residuals at the coefficient change d: one row
    // per sample and direction, J3 = d(residual)/d(coefficient) (rows x nu,
    // row-major) and rv = the residuals, both scaled by sqrt(weight).  res
    // is the weighted squared distance.  False if a projection fails.
    std::vector<ng::Vec<3>> dirs;
    ng::Point<3> q;
    auto evaluate = [&](const std::vector<double> & d, double & res,
                        std::vector<double> & J3, std::vector<double> & rv) {
      J3.clear();
      rv.clear();
      res = 0;
      for (int j = 0; j < np; j++) {
        ng::Point<3> x = x0[j];
        for (int k = 0; k < n; k++)
          for (int c = 0; c < 3; c++) x(c) += phi[k * np + j] * d[3 * k + c];
        if (!project(e, e.fit_el(j), e.fit_sn(j), e.fit_ref[j], x, q, dirs)) return false;
        const double sw = std::sqrt(e.fit_w[j]);
        for (const auto & nv : dirs) {
          double r = nv * (x - q);
          res += e.fit_w[j] * r * r;
          rv.push_back(sw * r);
          for (int k = 0; k < n; k++)
            for (int c = 0; c < 3; c++) J3.push_back(sw * nv(c) * phi[k * np + j]);
        }
      }
      return true;
    };

    // Reduced unknowns: coefficient k changes by sum_m u[k*nd+m] * dir_m.
    std::vector<ng::Vec<3>> fd = e.free_dirs;
    if (fd.empty())
      fd = {ng::Vec<3>(1, 0, 0), ng::Vec<3>(0, 1, 0), ng::Vec<3>(0, 0, 1)};
    const int nd = (int)fd.size();
    const int nr = n * nd;
    int rows = 0;
    auto reduce = [&](const std::vector<double> & J3, const std::vector<double> & rv3,
                      std::vector<double> & Jr, std::vector<double> & rvr) {
      rows = (int)rv3.size();
      Jr.assign(rows * nr, 0.0);
      rvr = rv3;
      for (int r = 0; r < rows; r++)
        for (int k = 0; k < n; k++)
          for (int m = 0; m < nd; m++) {
            double v = 0;
            for (int c = 0; c < 3; c++) v += J3[r * nu + 3 * k + c] * fd[m](c);
            Jr[r * nr + k * nd + m] = v;
          }
    };

    // The unknowns are the reduced changes u: coefficient k moves by
    // sum_m u[k*nd+m] * dir_m.  The objective is the weighted squared
    // distance plus a Tikhonov term lambda |u|^2.  Near-flat valleys of
    // equivalent re-parametrisations otherwise leave the minimiser
    // undetermined, and roundoff in the CAD projection then selects a
    // different point (and a different accept/reject outcome) per run.
    // lambda removes only directions whose curvature is below 1e-14 of the
    // strongest one; at 1e-10 it held the order-5 coefficients back.
    std::vector<double> d(nu, 0.0), A, b, Ar, br, M, s;
    auto to_d = [&](const std::vector<double> & uu) {
      std::vector<double> dd(nu, 0.0);
      for (int k = 0; k < n; k++)
        for (int m = 0; m < nd; m++)
          for (int c = 0; c < 3; c++) dd[3 * k + c] += uu[k * nd + m] * fd[m](c);
      return dd;
    };
    auto max_abs = [](const std::vector<double> & v) {
      double t = 0;
      for (double x : v) t = std::max(t, std::fabs(x));
      return t;
    };
    double res;
    if (!evaluate(d, res, A, b)) {
      for (int k = 0; k < n; k++) coef[k] = saved[k];
      return -1;
    }
    reduce(A, b, Ar, br);
    // Column squared norms of the reduced Jacobian (the normal-matrix diagonal).
    auto column_norms = [&](std::vector<double> & D) {
      D.assign(nr, 0.0);
      for (int r = 0; r < rows; r++)
        for (int i = 0; i < nr; i++) D[i] += Ar[r * nr + i] * Ar[r * nr + i];
    };
    std::vector<double> D;
    column_norms(D);
    double diag0 = 0;
    for (double v : D) diag0 = std::max(diag0, v);
    const double lambda = 1e-14 * diag0 + 1e-300;
    auto objective = [&](double r, const std::vector<double> & uu) {
      double t = r;
      for (double v : uu) t += lambda * v * v;
      return t;
    };
    // Step s minimising |Jr s + rv|^2 + lambda |u + s|^2 + damp sum D_i s_i^2,
    // as an augmented least-squares problem solved by QR.
    auto step_for = [&](const std::vector<double> & uu, double damp, std::vector<double> & ss) {
      column_norms(D);
      M.assign((rows + nr) * nr, 0.0);
      ss.assign(rows + nr, 0.0);
      for (int r = 0; r < rows; r++) {
        for (int i = 0; i < nr; i++) M[r * nr + i] = Ar[r * nr + i];
        ss[r] = -br[r];
      }
      for (int i = 0; i < nr; i++) {
        const double c = std::sqrt(lambda + damp * std::max(D[i], 1e-12 * diag0));
        M[(rows + i) * nr + i] = c;
        ss[rows + i] = -lambda * uu[i] / c;
      }
      if (!lstsq_qr(M, ss, rows + nr, nr)) return false;
      ss.resize(nr);
      return true;
    };

    // Gauss-Newton on the full (non-monotone) path: the tangential unknowns
    // couple to the distance only through the normal's rotation, and the
    // path to the minimum typically raises the residual on its first steps,
    // where a monotone method creeps.  Steps are capped by the trust region;
    // the best iterate is kept.
    std::vector<double> u(nr, 0.0), best_u = u;
    double obj = objective(res, u), best_obj = obj;
    int lm_it = 0;
    for (; lm_it < 25; lm_it++) {
      if (!step_for(u, 0.0, s)) break;
      double step = max_abs(s);
      const double cut = step > max_step ? max_step / step : 1.0;
      for (int i = 0; i < nr; i++) u[i] += cut * s[i];
      d = to_d(u);
      if (max_abs(d) > max_change) break;    // outside the trust region
      if (!evaluate(d, res, A, b)) break;    // left the valid projection range
      reduce(A, b, Ar, br);
      obj = objective(res, u);
      if (obj < best_obj) {
        best_obj = obj;
        best_u = u;
      }
      if (step * cut < 1e-15 * e.scale) break;
    }

    // Monotone Levenberg-Marquardt polish from the best iterate.
    u = best_u;
    d = to_d(u);
    if (!evaluate(d, res, A, b)) {
      for (int k = 0; k < n; k++) coef[k] = saved[k];
      return -1;
    }
    reduce(A, b, Ar, br);
    obj = objective(res, u);
    double mu = 1e-6;
    std::vector<double> ut, dt, At, bt;
    for (int it = 0; it < 60 && mu < 1e8; it++, lm_it++) {
      if (!step_for(u, mu, s)) break;
      ut = u;
      for (int i = 0; i < nr; i++) ut[i] += s[i];
      dt = to_d(ut);
      double rt;
      if (max_abs(dt) <= max_change && evaluate(dt, rt, At, bt) &&
          objective(rt, ut) < obj) {
        u = ut;
        d = dt;
        res = rt;
        obj = objective(rt, ut);
        A = At;
        b = bt;
        reduce(A, b, Ar, br);
        mu = std::max(mu * 0.1, 1e-12);
        if (max_abs(s) < 1e-15 * e.scale) break;
      } else {
        mu *= 10;
      }
    }

    for (int k = 0; k < n; k++)
      for (int c = 0; c < 3; c++) coef[k](c) = saved[k](c) + d[3 * k + c];

    after = max_distance(e);
    // Keep the refit only if it is closer to the geometry and every surface
    // area element and adjacent volume Jacobian stays within a factor of two
    // of its previous value at the same sample: a re-parametrisation must
    // neither fold nor blow up an element.
    const std::vector<double> area1 = area_samples(e), det1 = volume_det_samples(e);
    const bool areas_ok = within_factor_two(area0, area1);
    const bool volumes_ok = within_factor_two(det0, det1);
    if (std::getenv("CUBIT_MESH_EXPORT_GEOMETRIC_REFIT_DEBUG")) {
      int nonfinite = 0;
      auto range = [&](const std::vector<double> & a, const std::vector<double> & b) {
        double lo = 1e300, hi = -1e300;
        for (size_t i = 0; i < a.size(); i++) {
          if (!std::isfinite(a[i]) || !std::isfinite(b[i])) { nonfinite++; continue; }
          if (a[i] != 0) { lo = std::min(lo, b[i] / a[i]); hi = std::max(hi, b[i] / a[i]); }
        }
        return std::pair<double, double>(lo, hi);
      };
      auto ra = range(area0, area1), rv = range(det0, det1);
      double total = 0;
      for (int i = 0; i < nu; i++) total = std::max(total, std::fabs(d[i]));
      std::fprintf(stderr, "refit n=%d on_curve=%d before=%.3e after=%.3e "
                   "fit_rms=%.3e it=%d area_ratio[%.3f,%.3f] det_ratio[%.3f,%.3f] "
                   "nonfinite=%d areas_ok=%d volumes_ok=%d change/scale=%.3e\n",
                   n, int(e.on_curve), before, after, std::sqrt(res), lm_it,
                   ra.first, ra.second, rv.first, rv.second, nonfinite,
                   int(areas_ok), int(volumes_ok), total / e.scale);
    }
    const bool failed = after < 0;
    const bool degenerate = !areas_ok || !volumes_ok;
    const bool closer = !failed && after < before;
    bool within = true;
    if (closer && !e.group_limit.empty()) {
      const std::vector<double> g = group_max(e);
      within = !g.empty();
      for (size_t k = 0; within && k < g.size(); k++) within = g[k] <= e.group_limit[k];
    }
    if (!closer || degenerate || !within) {
      for (int k = 0; k < n; k++) coef[k] = saved[k];
      after = before;
      if (failed) return -1;
      if (!closer) return 0;
      return degenerate ? -2 : -3;   // -2: would distort; -3: beyond Netgen's distance
    }
    return 1;
  }
};

// Edge refit from two starts: Netgen's coefficients, and the same with the
// highest-degree coefficient removed (the edge's shape one order lower).
// The distance is not convex in the coefficients; from Netgen's order-5
// start the solve settles in a minimum 5x worse than the order-4 one, which
// the hierarchical basis contains.  The closer result is kept, and the
// second only if its elements stay within a factor two of Netgen's.
int refit_edge_two_starts(Refitter & R, const Entity & E, ng::Vec<3> * coef, int n,
                          double & before, double & after)
{
  std::vector<ng::Vec<3>> orig(coef, coef + n);
  const std::vector<double> area0 = R.area_samples(E), det0 = R.volume_det_samples(E);
  int r1 = R.refit(E, coef, n, before, after);
  if (n < 2 || before < 0) return r1;
  std::vector<ng::Vec<3>> c1(coef, coef + n);
  for (int k = 0; k < n; k++) coef[k] = orig[k];
  coef[n - 1] = ng::Vec<3>(0, 0, 0);
  double b2 = 0, a2 = 0;
  const int r2 = R.refit(E, coef, n, b2, a2);
  if (r2 > 0 && a2 < after && a2 < before &&
      Refitter::within_factor_two(area0, R.area_samples(E)) &&
      Refitter::within_factor_two(det0, R.volume_det_samples(E))) {
    after = a2;
    return 1;
  }
  for (int k = 0; k < n; k++) coef[k] = c1[k];
  return r1;
}

}  // namespace

GeometricRefitStats geometric_refit(ng::Mesh & mesh)
{
  GeometricRefitStats st;
  if (!mesh.GetGeometry() || !mesh.GetCurvedElements().IsHighOrder()) return st;

  Refitter R(mesh);
  const ng::MeshTopology & top = mesh.GetTopology();
  const int order = R.curved.GetOrder();

  // Edges that lie on a geometric curve (mesh segments).
  std::unordered_map<int, int> curve_edge;   // edge -> segment
  for (int i = 0; i < mesh.GetNSeg(); i++)
    curve_edge[top.GetEdge(ng::SegmentIndex::FromNr0(i)).Nr0()] = i;

  std::vector<double> g1, w1;
  gauss_rule(order + 6, g1, w1);
  const int ncheck = 4 * order + 9;

  // ---- Edges -------------------------------------------------------------
  std::vector<char> done(top.GetNEdges(), 0);
  std::vector<int> edge_surf(top.GetNEdges(), -2);
  std::vector<std::vector<ng::SurfaceElementIndex>> edge_sels(top.GetNEdges());
  for (int s = 0; s < mesh.GetNSE(); s++) {
    const auto sei = ng::SurfaceElementIndex::FromNr0(s);
    int sn = mesh.GetFaceDescriptor(mesh[sei].GetIndex()).SurfNr();
    for (auto e : top.GetEdges(sei)) {
      int ei = e.Nr0();
      edge_sels[ei].push_back(sei);
      if (edge_surf[ei] == -2) edge_surf[ei] = sn;
      else if (edge_surf[ei] != sn) edge_surf[ei] = -1;   // two surfaces
    }
  }

  // Edges that also fit adjacent order-2 triangles depend on their
  // neighbours, so they are swept three times (one sweep left the cone 3x
  // worse than the edge-only fit, three came within 10 %); the others once.
  // Statistics count each edge once: its first distance and last result.
  const int npass = 3;
  const double inf = std::numeric_limits<double>::infinity();
  // Netgen's coefficients are the baseline (user decision 2026-11-19): with
  // adjacent order-2 triangles, an edge refit is kept only when the edge and
  // each such triangle interior stay within their distance under Netgen's
  // coefficients, measured before any refit.
  std::vector<std::vector<ng::Vec<3>>> netgen_coef(top.GetNEdges());
  for (int ei = 0; ei < top.GetNEdges(); ei++) {
    const int n = R.curved.NumEdgeCoefficients(ei);
    if (n > 0) netgen_coef[ei].assign(R.curved.EdgeCoefficients(ei), R.curved.EdgeCoefficients(ei) + n);
  }
  // Limit grid used during the sweeps: strict-interior points (a, b) / m_lim
  // of a triangle and j / m_lim along an edge.  The final audit uses the
  // denser m_aud grid to estimate each entity's sup.
  const int m_lim = 12;
  std::vector<double> face_base(mesh.GetNSE(), inf);
  std::vector<Entity> face_audit(mesh.GetNSE());
  std::vector<double> face_audit_base(mesh.GetNSE(), inf);
  const int m_aud = 96;
  std::vector<char> has_face_audit(mesh.GetNSE(), 0);
  for (int s = 0; s < mesh.GetNSE(); s++) {
    const auto sei = ng::SurfaceElementIndex::FromNr0(s);
    const auto el = mesh[sei];
    if (el.GetType() != ng::TRIG || R.curved.NumFaceCoefficients(top.GetFace(sei).Nr0()) > 0) continue;
    Entity F;
    F.sei = sei;
    F.surfnr = mesh.GetFaceDescriptor(el.GetIndex()).SurfNr();
    F.scale = 0;
    for (int k = 0; k < 3; k++) F.scale = std::max(F.scale, ng::Dist(mesh[el[k]], mesh[el[(k + 1) % 3]]));
    for (int a = 1; a < m_lim; a++)
      for (int b = 1; a + b < m_lim; b++) F.check_ref.push_back({double(a) / m_lim, double(b) / m_lim});
    const double d = R.max_distance(F);
    if (d >= 0) face_base[s] = d;
    F.check_ref.clear();
    for (int a = 1; a < m_aud; a++)
      for (int b = 1; a + b < m_aud; b++) F.check_ref.push_back({double(a) / m_aud, double(b) / m_aud});
    face_audit[s] = F;   // its Netgen sup is evaluated only if an edge changes
    has_face_audit[s] = 1;
  }
  std::vector<char> tried(top.GetNEdges(), 0), ever_failed(top.GetNEdges(), 0),
      ever_distorted(top.GetNEdges(), 0), ever_limited(top.GetNEdges(), 0);
  std::vector<double> edge_base(top.GetNEdges(), inf), edge_after(top.GetNEdges(), 0);
  std::vector<Entity> edge_audit(top.GetNEdges());
  std::vector<double> edge_audit_base(top.GetNEdges(), inf);
  long step = 0;
  std::vector<long> fit_step(top.GetNEdges(), 0), mod_step(top.GetNEdges(), 0);
  auto t0 = std::chrono::steady_clock::now();
  for (int pass = 0; pass < npass; pass++) {
    std::fill(done.begin(), done.end(), 0);
    for (int s = 0; s < mesh.GetNSE(); s++) {
      const auto sei = ng::SurfaceElementIndex::FromNr0(s);
      const auto el = mesh[sei];
      auto edges = top.GetEdges(sei);
      auto local = ng::MeshTopology::GetEdges(el.GetType());
      for (int i = 0; i < edges.Size(); i++) {
        int ei = edges[i].Nr0();
        if (done[ei]) continue;
        done[ei] = 1;
        int n = R.curved.NumEdgeCoefficients(ei);
        if (n <= 0) continue;

        Entity E;
        E.sei = sei;
        auto it = curve_edge.find(ei);
        if (it != curve_edge.end()) {
          const ng::EdgeDescriptor & ed =
              mesh.GetEdgeDescriptor(mesh[ng::SegmentIndex::FromNr0(it->second)]);
          E.on_curve = true;
          E.surfnr1 = ed.SurfNr(0);
          E.surfnr2 = ed.SurfNr(1);
          E.edgenr = ed.EdgeNr();
        } else if (edge_surf[ei] >= 0) {
          E.surfnr = edge_surf[ei];
        } else {
          continue;   // an edge between surfaces without a geometric curve
        }
        auto ra = vertex_ref(el.GetType(), local[i][0]);
        auto rb = vertex_ref(el.GetType(), local[i][1]);
        E.scale = ng::Dist(mesh[el[local[i][0]]], mesh[el[local[i][1]]]);
        auto at = [&](double t) {
          return std::array<double, 2>{ra[0] + t * (rb[0] - ra[0]),
                                       ra[1] + t * (rb[1] - ra[1])};
        };
        for (size_t j = 0; j < g1.size(); j++) {
          E.fit_ref.push_back(at(g1[j]));
          E.fit_w.push_back(w1[j]);
        }
        // A triangle without face coefficients (order 2) takes its interior
        // shape from its edges alone.  Fitting the edge to the geometry by
        // itself then lets it slide along its chord and bend that interior
        // (measured 3.8x worse inside saddle-shaped torus triangles), so the
        // interiors of such adjacent triangles join the edge's fit samples,
        // each against its own surface.  An edge on a geometric curve stays
        // fitted to the curve alone (trading it against a neighbour lifted a
        // planar cap triangle off its plane), but still checks those
        // interiors: any accepted change of any edge of the triangle then
        // keeps the triangle within its Netgen distance on the final mesh.
        std::vector<ng::SurfaceElementIndex> tris;
        for (auto fs : edge_sels[ei]) {
          const auto fel = mesh[fs];
          if (fel.GetType() == ng::TRIG && R.curved.NumFaceCoefficients(top.GetFace(fs).Nr0()) == 0)
            tris.push_back(fs);
        }
        // With limits, the edge is checked on the same uniform grid as the
        // triangles (1/m_lim spacing), so edge and interior limits refer to
        // the same points before and after.
        if (tris.empty())
          for (int j = 1; j <= ncheck; j++) E.check_ref.push_back(at(double(j) / (ncheck + 1)));
        else
          for (int j = 1; j < m_lim; j++) E.check_ref.push_back(at(double(j) / m_lim));
        if (pass == 0) {   // the edge's own samples depend on its coefficients only
          const double d = R.max_distance(E);
          edge_base[ei] = d >= 0 ? d : inf;
          Entity A = E;   // the edge's own samples on the audit grid
          A.check_ref.clear();
          for (int j = 1; j < m_aud; j++) A.check_ref.push_back(at(double(j) / m_aud));
          edge_audit[ei] = A;
        }
        bool face_fit = false;
        for (auto fs : tris) {
          const auto fel = mesh[fs];
          if (E.fit_sei.empty()) {
            E.fit_sei.assign(E.fit_ref.size(), sei);
            E.fit_surf.assign(E.fit_ref.size(), -1);
            E.check_sei.assign(E.check_ref.size(), sei);
            E.check_surf.assign(E.check_ref.size(), -1);
            E.check_group.assign(E.check_ref.size(), 0);
            E.group_limit = {edge_base[ei]};
          }
          const int grp = (int)E.group_limit.size();
          E.group_limit.push_back(face_base[fs.Nr0()]);
          const int fsn = mesh.GetFaceDescriptor(fel.GetIndex()).SurfNr();
          if (!E.on_curve) {
            face_fit = true;
            for (size_t a = 0; a < g1.size(); a++)
              for (size_t b = 0; b < g1.size(); b++) {
                double yy = g1[b], xx = (1 - yy) * g1[a];
                E.fit_ref.push_back({xx, yy});
                E.fit_w.push_back(2 * w1[a] * w1[b] * (1 - yy));   // unit total per triangle
                E.fit_sei.push_back(fs);
                E.fit_surf.push_back(fsn);
              }
          }
          for (int a = 1; a < m_lim; a++)
            for (int b = 1; a + b < m_lim; b++) {
              E.check_ref.push_back({double(a) / m_lim, double(b) / m_lim});
              E.check_sei.push_back(fs);
              E.check_surf.push_back(fsn);
              E.check_group.push_back(grp);
            }
        }
        if (!E.on_curve && E.scale > 0) {
          ng::Vec<3> t0 = mesh[el[local[i][1]]] - mesh[el[local[i][0]]];
          t0 *= 1.0 / E.scale;
          ng::Point<3> q;
          std::vector<ng::Vec<3>> nd;
          auto rm = at(0.5);
          if (R.project(E, rm, R.eval(sei, rm), q, nd)) {
            ng::Vec<3> n0 = nd[0] - (nd[0] * t0) * t0;
            double l = n0.Length();
            if (l > 1e-8) E.free_dirs = {t0, (1.0 / l) * n0};
          }
        }

        E.volumes = shared_volumes(top, {el[local[i][0]], el[local[i][1]]});

        if (pass > 0 && !face_fit) continue;
        // A later sweep refits an edge only if a coupled edge (another edge
        // of an adjacent order-2 triangle) changed since its last fit.
        if (pass > 0) {
          bool dirty = false;
          for (auto fs : tris)
            for (auto e2 : top.GetEdges(fs))
              dirty = dirty || (e2.Nr0() != ei && mod_step[e2.Nr0()] > fit_step[ei]);
          if (!dirty) continue;
        }
        std::vector<ng::Vec<3>> prev(R.curved.EdgeCoefficients(ei), R.curved.EdgeCoefficients(ei) + n);
        double before = 0, after = 0;
        int r = refit_edge_two_starts(R, E, R.curved.EdgeCoefficients(ei), n, before, after);
        fit_step[ei] = ++step;
        for (int k = 0; k < n; k++)
          if (prev[k] != R.curved.EdgeCoefficients(ei)[k]) { mod_step[ei] = step; break; }
        tried[ei] = 1;
        if (r == -1) ever_failed[ei] = 1;
        if (r == -2) ever_distorted[ei] = 1;
        if (r == -3) ever_limited[ei] = 1;
        // Final distance of the edge's own samples (the last sweep's state).
        if (E.group_limit.empty()) {
          edge_after[ei] = after;
        } else {
          const std::vector<double> g = R.group_max(E);
          edge_after[ei] = g.empty() ? after : g[0];
        }
      }
    }
  }
  // Final audit on the final mesh (user decision 2026-11-19): every edge
  // and every order-2 triangle must stay within its Netgen distance on the
  // guard grid and the audit grids.  Where it does not, Netgen's coefficients of the edge (or of
  // all changed edges of the triangle) are restored, and the triangles next
  // to restored edges are audited again until nothing changes.  Restoring
  // only moves towards Netgen's state, so the loop terminates.  The guard is
  // a sampled check, not a continuous bound.
  auto differs = [&](int ei) {
    const int n = (int)netgen_coef[ei].size();
    const ng::Vec<3> * c = R.curved.EdgeCoefficients(ei);
    for (int k = 0; k < n; k++)
      for (int d = 0; d < 3; d++)
        if (c[k](d) != netgen_coef[ei][k](d)) return true;
    return false;
  };
  auto t1 = std::chrono::steady_clock::now();
  st.seconds_sweeps = std::chrono::duration<double>(t1 - t0).count();
  std::vector<char> restored(top.GetNEdges(), 0);
  auto restore = [&](int ei) {
    ng::Vec<3> * c = R.curved.EdgeCoefficients(ei);
    for (size_t k = 0; k < netgen_coef[ei].size(); k++) c[k] = netgen_coef[ei][k];
    restored[ei] = 1;
  };
  // Netgen's sup of an entity, evaluated lazily by swapping Netgen's
  // coefficients of the given edges in and the current ones back.
  auto netgen_sup = [&](const Entity & A, const std::vector<int> & eis) {
    std::vector<std::vector<ng::Vec<3>>> cur;
    for (int ei : eis) {
      ng::Vec<3> * c = R.curved.EdgeCoefficients(ei);
      cur.emplace_back(c, c + netgen_coef[ei].size());
      for (size_t k = 0; k < netgen_coef[ei].size(); k++) c[k] = netgen_coef[ei][k];
    }
    const double d = R.max_distance(A);
    for (size_t i = 0; i < eis.size(); i++) {
      ng::Vec<3> * c = R.curved.EdgeCoefficients(eis[i]);
      for (size_t k = 0; k < cur[i].size(); k++) c[k] = cur[i][k];
    }
    return d >= 0 ? d : inf;
  };
  // The candidate's sup is estimated on the 1/m_aud grid plus the change
  // from the 1/(m_aud/2) subgrid (a Richardson-type allowance for the peak
  // falling between samples); it must stay within Netgen's 1/m_aud sup.
  // One pass over the 1/m_aud samples gives both maxima: all points (d)
  // and the 1/(m_aud/2) subgrid (dh).
  auto sup_pair = [&](const Entity & A, double & d, double & dh) {
    d = dh = 0;
    ng::Point<3> q;
    std::vector<ng::Vec<3>> dirs;
    for (size_t j = 0; j < A.check_ref.size(); j++) {
      const auto & r = A.check_ref[j];
      ng::Point<3> x = R.eval(A.check_el(j), r);
      if (!R.project(A, A.check_el(j), A.check_sn(j), r, x, q, dirs)) return false;
      const double dj = ng::Dist(x, q);
      d = std::max(d, dj);
      if (std::lround(r[0] * m_aud) % 2 == 0 && std::lround(r[1] * m_aud) % 2 == 0) dh = std::max(dh, dj);
    }
    return true;
  };
  auto exceeds = [&](const Entity & A, double & base, const std::vector<int> & eis) {
    if (base < 0) base = netgen_sup(A, eis);   // -1: not yet evaluated
    if (!(base < inf)) return false;
    double d, dh;
    if (!sup_pair(A, d, dh)) return true;
    return d + std::max(0.0, d - dh) > base;
  };
  std::fill(edge_audit_base.begin(), edge_audit_base.end(), -1.0);
  std::fill(face_audit_base.begin(), face_audit_base.end(), -1.0);
  // An edge's own samples depend on its coefficients only, so each edge is
  // audited once.  A triangle that passed is audited again only after one
  // of its edges was restored.
  for (int ei = 0; ei < top.GetNEdges(); ei++)
    if (tried[ei] && differs(ei) && exceeds(edge_audit[ei], edge_audit_base[ei], {ei})) restore(ei);
  std::vector<char> face_ok(mesh.GetNSE(), 0);
  int round = 0;
  std::chrono::steady_clock::time_point t_re;
  for (bool again = true; again; round++) {
    if (round == 1) t_re = std::chrono::steady_clock::now();
    again = false;
    for (int s = 0; s < mesh.GetNSE(); s++) {
      if (!has_face_audit[s] || face_ok[s]) continue;
      const auto sei = ng::SurfaceElementIndex::FromNr0(s);
      std::vector<int> eis;
      bool any = false;
      for (auto e : top.GetEdges(sei)) {
        eis.push_back(e.Nr0());
        any = any || (netgen_coef[e.Nr0()].size() && differs(e.Nr0()));
      }
      if (!any || !exceeds(face_audit[s], face_audit_base[s], eis)) {
        face_ok[s] = 1;
        continue;
      }
      for (auto e : top.GetEdges(sei))
        if (netgen_coef[e.Nr0()].size() && differs(e.Nr0())) {
          restore(e.Nr0());
          for (auto fs : edge_sels[e.Nr0()]) face_ok[fs.Nr0()] = 0;
        }
      face_ok[s] = 1;   // now Netgen's map on all its edges
      again = true;
    }
  }
  const auto t2 = std::chrono::steady_clock::now();
  st.seconds_audit = std::chrono::duration<double>(t2 - t1).count();
  st.seconds_reaudit = round > 1 ? std::chrono::duration<double>(t2 - t_re).count() : 0.0;
  st.audit_rounds = round;
  for (int ei = 0; ei < top.GetNEdges(); ei++) {
    if (!tried[ei]) continue;
    st.edges_tried++;
    st.edges_restored_netgen += restored[ei];
    if (restored[ei]) edge_after[ei] = edge_base[ei];
    const int n = (int)netgen_coef[ei].size();
    const ng::Vec<3> * c = R.curved.EdgeCoefficients(ei);
    bool changed = false;
    for (int k = 0; k < n && !changed; k++)
      for (int d = 0; d < 3; d++) changed = changed || c[k](d) != netgen_coef[ei][k](d);
    if (changed) st.edges_accepted++;
    st.edges_failed += ever_failed[ei];
    st.edges_rejected_distortion += ever_distorted[ei];
    st.edges_kept_netgen_limit += ever_limited[ei];
    if (edge_base[ei] < inf) st.edge_dist_before = std::max(st.edge_dist_before, edge_base[ei]);
    st.edge_dist_after = std::max(st.edge_dist_after, edge_after[ei]);
  }

  // ---- Faces (after the edges they are blended with) ---------------------
  for (int s = 0; s < mesh.GetNSE(); s++) {
    const auto sei = ng::SurfaceElementIndex::FromNr0(s);
    const auto el = mesh[sei];
    int fi = top.GetFace(sei).Nr0();
    int n = R.curved.NumFaceCoefficients(fi);
    if (n <= 0) continue;

    Entity E;
    E.sei = sei;
    E.surfnr = mesh.GetFaceDescriptor(el.GetIndex()).SurfNr();
    E.scale = 0;
    for (int k = 0; k < el.GetNP(); k++)
      E.scale = std::max(E.scale, ng::Dist(mesh[el[k]], mesh[el[(k + 1) % el.GetNP()]]));
    const bool trig = el.GetType() == ng::TRIG;
    for (size_t a = 0; a < g1.size(); a++)
      for (size_t b = 0; b < g1.size(); b++) {
        if (trig) {   // collapsed (Duffy) rule on the reference triangle
          double y = g1[b], x = (1 - y) * g1[a];
          E.fit_ref.push_back({x, y});
          E.fit_w.push_back(w1[a] * w1[b] * (1 - y));
        } else {
          E.fit_ref.push_back({g1[a], g1[b]});
          E.fit_w.push_back(w1[a] * w1[b]);
        }
      }
    const int m = order + 4;
    for (int a = 1; a <= m; a++)
      for (int b = 1; b <= m; b++) {
        double x = double(a) / (m + 1), y = double(b) / (m + 1);
        if (trig && x + y >= 1) continue;
        E.check_ref.push_back({x, y});
      }

    // Faces keep all three directions: restricting them to the normal was
    // measured 2-3 orders worse, because the tangential re-parametrisation
    // is what lets the bubble degrees reduce the shape error.
    {
      std::vector<ng::PointIndex> fv;
      for (int k = 0; k < el.GetNP(); k++) fv.push_back(el[k]);
      E.volumes = shared_volumes(top, fv);
    }
    st.faces_tried++;
    double before = 0, after = 0;
    int r = R.refit(E, R.curved.FaceCoefficients(fi), n, before, after);
    if (r > 0) st.faces_accepted++;
    if (r == -1) st.faces_failed++;
    if (r == -2) st.faces_rejected_distortion++;
    st.face_dist_before = std::max(st.face_dist_before, before);
    st.face_dist_after = std::max(st.face_dist_after, after);
  }
  return st;
}

#else

GeometricRefitStats geometric_refit(netgen::Mesh &) { return {}; }

#endif
