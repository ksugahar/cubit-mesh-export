NGX_INLINE DLL_HEADER Ng_Point Ngx_Mesh :: GetPoint (int nr) const
{
  return Ng_Point (&mesh->Point(PointIndex::FromNr0(nr))(0));
}


template <>
NGX_INLINE DLL_HEADER int Ngx_Mesh :: GetElementIndex<0> (size_t nr) const
{
  return (*mesh).pointelements[nr].index.Nr1();
}

template <>
NGX_INLINE DLL_HEADER int Ngx_Mesh :: GetElementIndex<1> (size_t nr) const
{
  /*
  if(mesh->GetDimension()==3)
    return (*mesh)[SegmentIndex(nr)].edgenr;
  else
    return (*mesh)[SegmentIndex(nr)].si;
  */
  /*
  if(mesh->GetDimension()==3)
    return mesh->LineSegments()[nr].edgenr;
  else
    return mesh->LineSegments()[nr].si;
  */
  return (*mesh)[SegmentIndex::FromNr0(nr)].GetIndex().Nr1();
}
  
template <>
NGX_INLINE DLL_HEADER int Ngx_Mesh :: GetElementIndex<2> (size_t nr) const
{
  // int ind = (*mesh)[SurfaceElementIndex(nr)].GetIndex(); 
  // return mesh->GetFaceDescriptor(ind).BCProperty();
  const Element2dRef & el = (*mesh)[SurfaceElementIndex::FromNr0(nr)];
  return mesh->GetFaceDescriptor(el).BCProperty();
}

template <>
NGX_INLINE DLL_HEADER int Ngx_Mesh :: GetElementIndex<3> (size_t nr) const
{
  return (*mesh)[ElementIndex::FromNr0(nr)].GetIndex().Nr1();
}


template <>
NGX_INLINE DLL_HEADER Ng_Element Ngx_Mesh :: GetElement<0> (size_t nr) const
{
  const Element0d & el = mesh->pointelements[nr];
  
  Ng_Element ret;
  ret.type = NG_PNT;
  ret.index = el.index.Nr1();
  ret.mat = el.name;
  
  ret.points.num = 1;
  ret.points.ptr = (int*)&el.pnum;
  
  ret.vertices.num = 1;
  ret.vertices.ptr = (int*)&el.pnum;

  /*
  ret.edges.num = 0;
  ret.edges.ptr = NULL;
  */
  ret.edges.Assign ( FlatArray<T_EDGE2> (0, nullptr) );
  /*
  ret.faces.num = 0;
  ret.faces.ptr = NULL;
  */
  ret.faces.Assign ( { 0, nullptr } );  
  
  ret.facets.num = 1;
  ret.facets.base = POINTINDEX_BASE;
  ret.facets.ptr = (int*)&el.pnum;

  ret.mat = mesh->GetRegionName<0>(el.index.Nr1());
    
  ret.is_curved = false;
  return ret;
}



template <> 
NGX_INLINE DLL_HEADER Ng_Element Ngx_Mesh :: GetElement<1> (size_t nr) const
{
  // const Segment & el = mesh->LineSegment (SegmentIndex(nr));
  const Segment & el = (*mesh)[SegmentIndex::FromNr0(nr)];

  Ng_Element ret;
  ret.type = NG_ELEMENT_TYPE(el.GetType());
  ret.index = el.GetIndex().Nr1();
  ret.mat = mesh->HasEdgeDescriptor(el) ? string_view(mesh->GetEdgeDescriptor(el).GetName()) : Mesh::defaultmat_sv;

  ret.points.num = el.GetNP();
  ret.points.ptr = (int*)&(el[0]);

  ret.vertices.num = 2;
  ret.vertices.ptr = (int*)&(el[0]);

  auto hedges = mesh->GetTopology().GetEdges (SegmentIndex::FromNr0(nr));
  ret.edges.Assign ( { hedges.Size(), (T_EDGE2*)hedges.Data() } );

  /*
  ret.faces.num = 0;
  ret.faces.ptr = NULL;
  */
  ret.faces.Assign ( { 0, nullptr });
  
  if (mesh->GetDimension() == 3)
    {
      ret.facets.num = 0;
      ret.facets.base = 0;
      ret.facets.ptr = nullptr;
    }
  else if (mesh->GetDimension() == 2)
    {
      ret.facets.num = 1;
      ret.facets.base = 0;
      ret.facets.ptr = ret.edges.Data();
    }
  else
    {
      ret.facets.num = 2;
      ret.facets.base = POINTINDEX_BASE;
      ret.facets.ptr = (int*)&(el[0]);
    }

  // ret.is_curved = mesh->GetCurvedElements().IsCurved(SegmentIndex::FromNr0(nr));
  ret.is_curved = mesh->HasEdgeDescriptor(el) && mesh->GetEdgeDescriptor(el).EdgeNr() > 0;

  return ret;
}

template <> 
NGX_INLINE DLL_HEADER Ng_Element Ngx_Mesh :: GetElement<2> (size_t nr) const
{
  const Element2dRef & el = (*mesh)[SurfaceElementIndex::FromNr0(nr)];
  
  Ng_Element ret;
  ret.type = NG_ELEMENT_TYPE(el.GetType());
  ret.index = el.GetIndex().Nr1();   // region = face descriptor
  ret.mat = mesh->GetFaceDescriptor(el).GetBCName();
  ret.points.num = el.GetNP();
  ret.points.ptr  = (int*)&el[0];

  ret.vertices.num = el.GetNV();
  ret.vertices.ptr = (int*)&(el[0]);

  /*
  ret.edges.num = MeshTopology::GetNEdges (el.GetType());
  ret.edges.ptr = mesh->GetTopology().GetSurfaceElementEdgesPtr (nr);
  */

  // ret.edges.Assign (mesh->GetTopology().GetEdges (SurfaceElementIndex(nr)));
  auto hedges = mesh->GetTopology().GetEdges (SurfaceElementIndex::FromNr0(nr));
  ret.edges.Assign ( { hedges.Size(), (int*)hedges.Data() } );
  
  auto hfaces = mesh->GetTopology().GetFaces (SurfaceElementIndex::FromNr0(nr));
  ret.faces.Assign ( { hfaces.Size(), (int*)hfaces.Data() } );
  
  if (mesh->GetDimension() == 3)
    {
      ret.facets.num = ret.faces.Size();
      ret.facets.base = 0;
      ret.facets.ptr = ret.faces.Data();
    }
  else
    {
      ret.facets.num = ret.edges.Size();
      ret.facets.base = 0;      
      ret.facets.ptr = ret.edges.Data();
    }
  ret.is_curved = el.IsCurved();
  ret.newest_vertex = el.NewestVertex();
  return ret;
}

template <> 
NGX_INLINE DLL_HEADER Ng_Element Ngx_Mesh :: GetElement<3> (size_t nr) const
{
  auto el = (*mesh)[ElementIndex::FromNr0(nr)];
  
  Ng_Element ret;
  ret.type = NG_ELEMENT_TYPE(el.GetType());
  ret.index = el.GetIndex().Nr1();
  ret.mat = *(mesh -> GetMaterialPtr(ret.index));
  ret.points.num = el.GetNP();
  ret.points.ptr = (int*)&el[0];

  ret.vertices.num = el.GetNV();
  ret.vertices.ptr = (int*)&(el[0]);

  /*
  ret.edges.num = MeshTopology::GetNEdges (el.GetType());
  ret.edges.ptr = mesh->GetTopology().GetElementEdgesPtr (nr);
  */
  // ret.edges.Assign (mesh->GetTopology().GetEdges (ElementIndex(nr)));
  auto hedges = mesh->GetTopology().GetEdges (ElementIndex::FromNr0(nr));
  ret.edges.Assign ( { hedges.Size(), (int*)hedges.Data() } );
  

  /*
  ret.faces.num = MeshTopology::GetNFaces (el.GetType());
  ret.faces.ptr = mesh->GetTopology().GetElementFacesPtr (nr);
  */
  // ret.faces.Assign (mesh->GetTopology().GetFaces (ElementIndex(nr)));
  auto hfaces = mesh->GetTopology().GetFaces (ElementIndex::FromNr0(nr));
  ret.faces.Assign ( { hfaces.Size(), (int*)hfaces.Data() } );
  
  ret.facets.num = ret.faces.Size();
  ret.facets.base = 0;
  ret.facets.ptr = ret.faces.Data();

  ret.is_curved = el.IsCurved();
  ret.newest_vertex = el.NewestVertex();
  return ret;
}



template <> NGX_INLINE DLL_HEADER
string_view Ngx_Mesh :: GetMaterialCD<0> (int region_nr) const
{
  return mesh->GetMaterial(region_nr+1);
}

template <> NGX_INLINE DLL_HEADER
string_view Ngx_Mesh :: GetMaterialCD<1> (int region_nr) const
{
  return mesh->GetRegionName(mesh->GetDimension()-1, region_nr+1);
}

template <> NGX_INLINE DLL_HEADER
string_view Ngx_Mesh :: GetMaterialCD<2> (int region_nr) const
{
  return mesh->GetRegionName(mesh->GetDimension()-2, region_nr+1);
}

template <> NGX_INLINE DLL_HEADER
string_view Ngx_Mesh :: GetMaterialCD<3> (int region_nr) const
{
  return mesh->GetCD3Name(region_nr);
}





template <> NGX_INLINE DLL_HEADER int Ngx_Mesh :: GetNNodes<1> ()
{
  return mesh->GetTopology().GetNEdges();
}

template <> NGX_INLINE DLL_HEADER int Ngx_Mesh :: GetNNodes<2> ()
{
  return mesh->GetTopology().GetNFaces();
}

template <> NGX_INLINE DLL_HEADER const Ng_Node<0> Ngx_Mesh :: GetNode<0> (int vnr_) const
{
  Ng_Node<0> node;
  PointIndex vnr = IndexBASE<PointIndex>() + vnr_;
  switch (mesh->GetDimension())
    {
    case 3:
      {
        auto ia = mesh->GetTopology().GetVertexElements(vnr);
        node.elements.ne = ia.Size();
        node.elements.ptr = (int*)ia.Data();
        
        auto bia = mesh->GetTopology().GetVertexSurfaceElements(vnr);
        node.bnd_elements.ne = bia.Size();
        node.bnd_elements.ptr = (int*)bia.Data();
        break;
      }
    case 2:
      {
        auto ia = mesh->GetTopology().GetVertexSurfaceElements(vnr);
        node.elements.ne = ia.Size();
        node.elements.ptr = (int*)ia.Data();
        
        auto bia = mesh->GetTopology().GetVertexSegments(vnr);
        node.bnd_elements.ne = bia.Size();
        node.bnd_elements.ptr = (int*)bia.Data();
        break;
      }
    case 1:
      {
        auto ia = mesh->GetTopology().GetVertexSegments(vnr);
        node.elements.ne = ia.Size();
        node.elements.ptr = (int*)ia.Data();
        
        auto bia = mesh->GetTopology().GetVertexPointElements(vnr);
        node.bnd_elements.ne = bia.Size();
        node.bnd_elements.ptr = (int*)bia.Data();
        break;
      }
    default:
      ;
    }
  return node;
}
  
template <> NGX_INLINE DLL_HEADER const Ng_Node<1> Ngx_Mesh :: GetNode<1> (int nr) const
{
  Ng_Node<1> node;
  node.vertices.ptr = (const int*)mesh->GetTopology().GetEdgeVerticesPtr(EdgeIndex::FromNr0(nr));
  return node;
}

template <> NGX_INLINE DLL_HEADER const Ng_Node<2> Ngx_Mesh :: GetNode<2> (int nr) const
{
  Ng_Node<2> node;
  node.vertices.ptr = (const int*)mesh->GetTopology().GetFaceVerticesPtr(FaceIndex::FromNr0(nr));
  node.vertices.nv = (node.vertices.ptr[3]+1 == PointIndex::BASE) ? 3 : 4;
  node.surface_el = mesh->GetTopology().GetFace2SurfaceElement (FaceIndex::FromNr0(nr)).Nr0();
  return node;
}


NGX_INLINE DLL_HEADER Ng_Buffer<int[2]> Ngx_Mesh :: GetPeriodicVertices(int idnr) const
{
  Array<PointIndices<2>> apairs;
  mesh->GetIdentifications().GetPairs (idnr+1, apairs);
  typedef int ti2[2];
  ti2 * pairs = new ti2[apairs.Size()];
  for (size_t i = 0; i < apairs.Size(); i++)
    {
      pairs[i][0] = apairs[i][0] - IndexBASE<PointIndex>();
      pairs[i][1] = apairs[i][1] - IndexBASE<PointIndex>();
    }
  return { apairs.Size(), pairs };
}


NGX_INLINE void Ngx_Mesh :: GetParentNodes (int ni, int * parents) const
{
  auto pi = PointIndex::FromNr0(ni);
  if (mesh->mlbetweennodes.Range().Contains(pi))
    for (int j = 0; j < 2; j++)
      parents[j] = mesh->mlbetweennodes[pi][j].Nr0();
  else
    parents[0] = parents[1] = -1;
}

inline bool Ngx_Mesh :: HasParentEdges() const
{
  return mesh->GetTopology().HasParentEdges();
}

inline tuple<int, std::array<int,3>> Ngx_Mesh :: GetParentEdges (int enr) const
{
  auto [info, nrs] = mesh->GetTopology().GetParentEdges(EdgeIndex::FromNr0(enr));
  return { info, { nrs[0].Nr0(), nrs[1].Nr0(), nrs[2].Nr0() } };
}

inline tuple<int, std::array<int,4>> Ngx_Mesh :: GetParentFaces (int fnr) const
{
  auto [info, nrs] = mesh->GetTopology().GetParentFaces(FaceIndex::FromNr0(fnr));
  return { info, { nrs[0].Nr0(), nrs[1].Nr0(), nrs[2].Nr0(), nrs[3].Nr0() } };
}


inline auto Ngx_Mesh :: GetTimeStamp() const { return mesh->GetTimeStamp(); }
