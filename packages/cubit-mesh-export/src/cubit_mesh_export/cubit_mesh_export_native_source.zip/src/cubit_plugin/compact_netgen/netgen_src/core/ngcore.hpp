#ifndef NETGEN_CORE_NGCORE_HPP
#define NETGEN_CORE_NGCORE_HPP

#include "archive.hpp"
#include "array.hpp"
#include "bitarray.hpp"
#include "blockallocator.hpp"
#include "exception.hpp"
#include "flags.hpp"
#include "table.hpp"
#include "dynstridearray.hpp"
#include "hashtable.hpp"
#include "indexset.hpp"
#include "localheap.hpp"
#include "logging.hpp"
// #include "mpi_wrapper.hpp"
#include "profiler.hpp"
#include "signal.hpp"
#include "simd.hpp"
#include "autodiff.hpp"
#include "autodiffdiff.hpp"
#include "symboltable.hpp"
#include "taskmanager.hpp"
#include "version.hpp"
#include "xbool.hpp"
#include "ngstream.hpp"
#include "utils.hpp"
#include "ranges.hpp"
#include "statushandler.hpp"

#endif // NETGEN_CORE_NGCORE_HPP




