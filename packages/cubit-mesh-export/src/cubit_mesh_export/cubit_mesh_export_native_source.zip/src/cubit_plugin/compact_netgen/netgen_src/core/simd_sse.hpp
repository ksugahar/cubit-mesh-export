#ifndef NETGEN_CORE_SIMD_SSE_HPP
#define NETGEN_CORE_SIMD_SSE_HPP

/**************************************************************************/
/* File:   simd_sse.hpp                                                   */
/* Author: Joachim Schoeberl, Matthias Hochsteger                         */
/* Date:   25. Mar. 16                                                    */
/**************************************************************************/

#include <immintrin.h>

namespace ngcore
{

  template <>
  class SIMD<mask64,2>
  {
    __m128i mask;
  public:
    SIMD (int i)
      : mask(_mm_cmpgt_epi32(_mm_set1_epi32(i),
                             _mm_set_epi32(1, 1, 0, 0)))
    { ; }

    SIMD (bool i0, bool i1) { mask = _mm_set_epi64x(i1?-1:0, i0?-1:0); }
    
    SIMD (__m128i _mask) : mask(_mask) { ; }
    __m128i Data() const { return mask; }
    static constexpr int Size() { return 2; }
    static NETGEN_INLINE SIMD<mask64, 2> GetMaskFromBits (unsigned int i);
  };

  static SIMD<mask64, 2> masks_from_2bits[4] = {
    _mm_set_epi32 (0,0,0,0), _mm_set_epi32 (0,0,-1,0),
    _mm_set_epi32 (-1,0,0,0), _mm_set_epi32 (-1,0,-1,0),
  };

  NETGEN_INLINE SIMD<mask64, 2> SIMD<mask64, 2> :: GetMaskFromBits (unsigned int i)
  {
    return masks_from_2bits[i & 3];
  }


  template<>
  class alignas(16) SIMD<int64_t,2>
  {
    __m128i data;

  public:
    static constexpr int Size() { return 2; }
    SIMD () {}
    SIMD (const SIMD &) = default;
    SIMD (int64_t v0, int64_t v1) { data = _mm_set_epi64x(v1,v0); }
    SIMD (std::array<int64_t, 2> arr)
        : data{_mm_set_epi64x(arr[1],arr[0])}
    {}

    SIMD & operator= (const SIMD &) = default;

    SIMD (int64_t val) { data = _mm_set1_epi64x(val); }
    SIMD (__m128i _data) { data = _data; }

    template<typename T, typename std::enable_if<std::is_convertible<T, std::function<int64_t(int)>>::value, int>::type = 0>
    SIMD (const T & func)
    {
      data = _mm_set_epi64(func(1), func(0));
    }

    NETGEN_INLINE auto operator[] (int i) const { return ((int64_t*)(&data))[i]; }
    NETGEN_INLINE __m128i Data() const { return data; }
    NETGEN_INLINE __m128i & Data() { return data; }
    // NETGEN_INLINE int64_t Lo() const { return _mm_extract_epi64(data, 0); }
    // NETGEN_INLINE int64_t Hi() const { return _mm_extract_epi64(data, 1); }
    NETGEN_INLINE int64_t Lo() const { return ((int64_t*)(&data))[0]; }
    NETGEN_INLINE int64_t Hi() const { return ((int64_t*)(&data))[1]; }
    static SIMD FirstInt(int n0=0) { return { n0, n0+1 }; }
  };



NETGEN_INLINE SIMD<int64_t,2> operator-(SIMD<int64_t,2> a) { return _mm_sub_epi64(_mm_setzero_si128(), a.Data()); }
NETGEN_INLINE SIMD<int64_t,2> operator+ (SIMD<int64_t,2> a, SIMD<int64_t,2> b) { return _mm_add_epi64(a.Data(),b.Data()); }
NETGEN_INLINE SIMD<int64_t,2> operator- (SIMD<int64_t,2> a, SIMD<int64_t,2> b) { return _mm_sub_epi64(a.Data(),b.Data()); }


  template<>
  class alignas(16) SIMD<double,2>
  {
    __m128d data;

  public:
    static constexpr int Size() { return 2; }
    SIMD () {}
    SIMD (const SIMD &) = default;
    SIMD (double v0, double v1) { data = _mm_set_pd(v1,v0); }
    SIMD (SIMD<double,1> v0, SIMD<double,1> v1)
        : data{_mm_set_pd(v0.Data(), v1.Data())}
    { }
    SIMD (std::array<double, 2> arr)
        : data{_mm_set_pd(arr[1], arr[0])}
    {}

    SIMD & operator= (const SIMD &) = default;

    SIMD (double val) { data = _mm_set1_pd(val); }
    SIMD (int val)    { data = _mm_set1_pd(val); }
    SIMD (size_t val) { data = _mm_set1_pd(val); }

    SIMD (double const * p) { data = _mm_loadu_pd(p); }
    SIMD (double const * p, SIMD<mask64,2> mask)
      {
#ifdef __AVX__
        data = _mm_maskload_pd(p, mask.Data());
#else
        // this versions segfaults if p points to the last allowed element
        // happened on Mac with the new SparseCholesky-factorization
        // data = _mm_and_pd(_mm_castsi128_pd(mask.Data()), _mm_loadu_pd(p));
        auto pmask = (int64_t*)&mask;
        data = _mm_set_pd (pmask[1] ? p[1] : 0.0, pmask[0] ? p[0] : 0.0);
#endif
      }
    SIMD (__m128d _data) { data = _data; }

    void Store (double * p) { _mm_storeu_pd(p, data); }
    void Store (double * p, SIMD<mask64,2> mask)
    {
#ifdef __AVX__
      _mm_maskstore_pd(p, mask.Data(), data);
#else
      /*
      _mm_storeu_pd (p, _mm_or_pd (_mm_and_pd(_mm_castsi128_pd(mask.Data()), data),
                                   _mm_andnot_pd(_mm_castsi128_pd(mask.Data()), _mm_loadu_pd(p))));
      */
      auto pmask = (int64_t*)&mask;
      if (pmask[0]) p[0] = (*this)[0];
      if (pmask[1]) p[1] = (*this)[1];
#endif
    }

    template<typename T, typename std::enable_if<std::is_convertible<T, std::function<double(int)>>::value, int>::type = 0>
    SIMD (const T & func)
    {
      data = _mm_set_pd(func(1), func(0));
    }

    NETGEN_INLINE double operator[] (int i) const { return ((double*)(&data))[i]; }
    NETGEN_INLINE __m128d Data() const { return data; }
    NETGEN_INLINE __m128d & Data() { return data; }

    template <int I>
    double Get() const
    {
      static_assert(I>=0 && I<2, "Index out of range");
      return (*this)[I];
    }

    double Lo() const { return Get<0>(); } 
    double Hi() const { return Get<1>(); } 
    
    operator std::tuple<double&,double&> ()
    {
      auto pdata = (double*)&data;
      return std::tuple<double&,double&>(pdata[0], pdata[1]);
    }
  };

  NETGEN_INLINE SIMD<double,2> operator- (SIMD<double,2> a) { return _mm_xor_pd(a.Data(), _mm_set1_pd(-0.0)); }
  NETGEN_INLINE SIMD<double,2> operator+ (SIMD<double,2> a, SIMD<double,2> b) { return _mm_add_pd(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<double,2> operator- (SIMD<double,2> a, SIMD<double,2> b) { return _mm_sub_pd(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<double,2> operator* (SIMD<double,2> a, SIMD<double,2> b) { return _mm_mul_pd(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<double,2> operator/ (SIMD<double,2> a, SIMD<double,2> b) { return _mm_div_pd(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<double,2> operator* (double a, SIMD<double,2> b) { return _mm_set1_pd(a)*b; }
  NETGEN_INLINE SIMD<double,2> operator* (SIMD<double,2> b, double a) { return _mm_set1_pd(a)*b; }

  template<>
  NETGEN_INLINE auto Unpack (SIMD<double,2> a, SIMD<double,2> b)
  {
    return std::make_tuple(SIMD<double,2>(_mm_unpacklo_pd(a.Data(),b.Data())),
                      SIMD<double,2>(_mm_unpackhi_pd(a.Data(),b.Data())));
  }

  NETGEN_INLINE __m128d my_mm_hadd_pd(__m128d a, __m128d b) {
#if defined(__SSE3__) || defined(__AVX__)
    return _mm_hadd_pd(a,b);
#else
    return _mm_add_pd( _mm_unpacklo_pd(a,b), _mm_unpackhi_pd(a,b) );
#endif
  }

#ifndef __AVX__
  NETGEN_INLINE __m128i my_mm_cmpgt_epi64(__m128i a, __m128i b) {
    auto  res_lo = _mm_cvtsi128_si64(a)  > _mm_cvtsi128_si64(b) ? -1:0;
    auto  res_hi = _mm_cvtsi128_si64(_mm_srli_si128(a,8)) > _mm_cvtsi128_si64(_mm_srli_si128(b,8)) ? -1 : 0;
    return _mm_set_epi64x(res_hi,res_lo);
  }
#else
  NETGEN_INLINE __m128i my_mm_cmpgt_epi64(__m128i a, __m128i b) {
    return _mm_cmpgt_epi64(a,b);
  }
#endif


  NETGEN_INLINE SIMD<double,2> sqrt (SIMD<double,2> a) { return _mm_sqrt_pd(a.Data()); }
  NETGEN_INLINE SIMD<double,2> fabs (SIMD<double,2> a) { return _mm_max_pd(a.Data(), (-a).Data()); }
  using std::floor;
  NETGEN_INLINE SIMD<double,2> floor (SIMD<double,2> a)
  { return ngcore::SIMD<double,2>([&](int i)->double { return floor(a[i]); } ); }
  using std::ceil;
  NETGEN_INLINE SIMD<double,2> ceil (SIMD<double,2> a)
  { return ngcore::SIMD<double,2>([&](int i)->double { return ceil(a[i]); } ); }

  NETGEN_INLINE SIMD<mask64,2> operator<= (SIMD<double,2> a , SIMD<double,2> b)
  { return _mm_castpd_si128( _mm_cmple_pd(a.Data(),b.Data())); }
  NETGEN_INLINE SIMD<mask64,2> operator< (SIMD<double,2> a , SIMD<double,2> b)
  { return _mm_castpd_si128( _mm_cmplt_pd(a.Data(),b.Data())); }
  NETGEN_INLINE SIMD<mask64,2> operator>= (SIMD<double,2> a , SIMD<double,2> b)
  { return _mm_castpd_si128( _mm_cmpge_pd(a.Data(),b.Data())); }
  NETGEN_INLINE SIMD<mask64,2> operator> (SIMD<double,2> a , SIMD<double,2> b)
  { return _mm_castpd_si128( _mm_cmpgt_pd(a.Data(),b.Data())); }
  NETGEN_INLINE SIMD<mask64,2> operator== (SIMD<double,2> a , SIMD<double,2> b)
  { return _mm_castpd_si128( _mm_cmpeq_pd(a.Data(),b.Data())); }
  NETGEN_INLINE SIMD<mask64,2> operator!= (SIMD<double,2> a , SIMD<double,2> b)
  { return _mm_castpd_si128( _mm_cmpneq_pd(a.Data(),b.Data())); }

#ifdef __SSE4_2__  
  NETGEN_INLINE SIMD<mask64,2> operator<= (SIMD<int64_t,2> a , SIMD<int64_t,2> b)
  { return  _mm_xor_si128(_mm_cmpgt_epi64(a.Data(),b.Data()),_mm_set1_epi32(-1)); }
  NETGEN_INLINE SIMD<mask64,2> operator< (SIMD<int64_t,2> a , SIMD<int64_t,2> b)
  { return  my_mm_cmpgt_epi64(b.Data(),a.Data()); }
  NETGEN_INLINE SIMD<mask64,2> operator>= (SIMD<int64_t,2> a , SIMD<int64_t,2> b)
  { return  _mm_xor_si128(_mm_cmpgt_epi64(b.Data(),a.Data()),_mm_set1_epi32(-1)); }
  NETGEN_INLINE SIMD<mask64,2> operator> (SIMD<int64_t,2> a , SIMD<int64_t,2> b)
  { return  my_mm_cmpgt_epi64(a.Data(),b.Data()); }
#endif
#ifdef __SSE4_1__  
  NETGEN_INLINE SIMD<mask64,2> operator== (SIMD<int64_t,2> a , SIMD<int64_t,2> b)
  { return  _mm_cmpeq_epi64(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<mask64,2> operator!= (SIMD<int64_t,2> a , SIMD<int64_t,2> b)
  { return  _mm_xor_si128(_mm_cmpeq_epi64(a.Data(),b.Data()),_mm_set1_epi32(-1)); }
#endif


 NETGEN_INLINE SIMD<mask64,2> operator&& (SIMD<mask64,2> a, SIMD<mask64,2> b)
  { return _mm_castpd_si128(_mm_and_pd (_mm_castsi128_pd(a.Data()),_mm_castsi128_pd( b.Data()))); }
  NETGEN_INLINE SIMD<mask64,2> operator|| (SIMD<mask64,2> a, SIMD<mask64,2> b)
  { return _mm_castpd_si128(_mm_or_pd (_mm_castsi128_pd(a.Data()), _mm_castsi128_pd(b.Data()))); }
  NETGEN_INLINE SIMD<mask64,2> operator! (SIMD<mask64,2> a)
  { return _mm_castpd_si128(_mm_xor_pd (_mm_castsi128_pd(a.Data()),_mm_castsi128_pd( _mm_cmpeq_epi64(a.Data(),a.Data())))); }
#ifdef __SSE4_1__
  NETGEN_INLINE SIMD<double,2> If (SIMD<mask64,2> a, SIMD<double,2> b, SIMD<double,2> c)
  { return _mm_blendv_pd(c.Data(), b.Data(), _mm_castsi128_pd(a.Data())); }
#else
  NETGEN_INLINE SIMD<double,2> If (SIMD<mask64,2> a, SIMD<double,2> b, SIMD<double,2> c)
  {
    return _mm_or_pd(
                      _mm_andnot_pd(_mm_castsi128_pd(a.Data()),c.Data()),
                      _mm_and_pd(b.Data(),_mm_castsi128_pd(a.Data()))
                      );}
#endif // __SSE4_1__

  NETGEN_INLINE SIMD<double,2> IfPos (SIMD<double,2> a, SIMD<double,2> b, SIMD<double,2> c)
  { return ngcore::SIMD<double,2>([&](int i)->double { return a[i]>0 ? b[i] : c[i]; }); }
  NETGEN_INLINE SIMD<double,2> IfZero (SIMD<double,2> a, SIMD<double,2> b, SIMD<double,2> c)
  { return ngcore::SIMD<double,2>([&](int i)->double { return a[i]==0. ? b[i] : c[i]; }); }


  NETGEN_INLINE double HSum (SIMD<double,2> sd)
  {
    return _mm_cvtsd_f64 (my_mm_hadd_pd (sd.Data(), sd.Data()));
  }

  NETGEN_INLINE auto HSum (SIMD<double,2> sd1, SIMD<double,2> sd2)
  {
    __m128d hv2 = my_mm_hadd_pd(sd1.Data(), sd2.Data());
    return SIMD<double,2> (hv2);
    // return SIMD<double,2>(_mm_cvtsd_f64 (hv2),  _mm_cvtsd_f64(_mm_shuffle_pd (hv2, hv2, 3)));
  }

  NETGEN_INLINE SIMD<int64_t, 2> If(SIMD<mask64, 2> a, SIMD<int64_t, 2> b,
                             SIMD<int64_t, 2> c) {
    return _mm_or_si128(
                        _mm_andnot_si128(a.Data(),c.Data()),
                        _mm_and_si128(b.Data(),a.Data())
                        );
  }


  // *************************** float ***************************

  // stored in the lower half of an xmm register, upper lanes are undefined
  template<>
  class alignas(16) SIMD<float,2>
  {
    __m128 data;

  public:
    static constexpr int Size() { return 2; }
    SIMD () {}
    SIMD (const SIMD &) = default;
    SIMD (float v0, float v1) : data{_mm_setr_ps(v0,v1,0,0)} { }
    SIMD (SIMD<float,1> v0, SIMD<float,1> v1) : SIMD(v0.Data(), v1.Data()) { }
    SIMD (std::array<float, 2> arr) : SIMD(arr[0], arr[1]) { }

    SIMD & operator= (const SIMD &) = default;

    SIMD (float val)  : data{_mm_set1_ps(val)} { }
    SIMD (double val) : SIMD(float(val)) { }
    SIMD (int val)    : SIMD(float(val)) { }
    SIMD (size_t val) : SIMD(float(val)) { }

    SIMD (float const * p) : data{_mm_castpd_ps(_mm_load_sd((double const*)p))} { }

    SIMD (__m128 _data) : data{_data} { }

    template<typename T, typename std::enable_if<std::is_convertible<T, std::function<float(int)>>::value, int>::type = 0>
    SIMD (const T & func)
    {
      data = _mm_setr_ps(func(0), func(1), 0, 0);
    }

    void Store (float * p)
    {
      _mm_store_sd((double*)p, _mm_castps_pd(data));
    }

    NETGEN_INLINE float operator[] (int i) const { return ((float*)(&data))[i]; }
    NETGEN_INLINE float & operator[] (int i) { return ((float*)(&data))[i]; }

    template <int I>
    float Get() const
    {
      static_assert(I>=0 && I<2, "Index out of range");
      return (*this)[I];
    }

    NETGEN_INLINE __m128 Data() const { return data; }
    NETGEN_INLINE __m128 & Data() { return data; }

    float Lo() const { return Get<0>(); }
    float Hi() const { return Get<1>(); }
  };

  NETGEN_INLINE SIMD<float,2> operator- (SIMD<float,2> a) { return _mm_xor_ps(a.Data(), _mm_set1_ps(-0.0f)); }
  NETGEN_INLINE SIMD<float,2> operator+ (SIMD<float,2> a, SIMD<float,2> b) { return _mm_add_ps(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<float,2> operator- (SIMD<float,2> a, SIMD<float,2> b) { return _mm_sub_ps(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<float,2> operator* (SIMD<float,2> a, SIMD<float,2> b) { return _mm_mul_ps(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<float,2> operator/ (SIMD<float,2> a, SIMD<float,2> b) { return _mm_div_ps(a.Data(),b.Data()); }

  NETGEN_INLINE float HSum (SIMD<float,2> a)
  {
    __m128 t = _mm_add_ss(a.Data(), _mm_shuffle_ps(a.Data(), a.Data(), 1));
    return _mm_cvtss_f32(t);
  }

  NETGEN_INLINE SIMD<float,2> FMA (SIMD<float,2> a, SIMD<float,2> b, SIMD<float,2> c)
  {
#ifdef __FMA__
    return _mm_fmadd_ps(a.Data(), b.Data(), c.Data());
#else
    return a*b+c;
#endif
  }

  NETGEN_INLINE SIMD<float,2> FMA (const float & a, SIMD<float,2> b, SIMD<float,2> c)
  {
    return FMA(SIMD<float,2> (a), b, c);
  }


  template<>
  class alignas(16) SIMD<float,4>
  {
    __m128 data;

  public:
    static constexpr int Size() { return 4; }
    SIMD () {}
    SIMD (const SIMD &) = default;
    SIMD (float v0, float v1, float v2, float v3) : data{_mm_setr_ps(v0,v1,v2,v3)} { }
    SIMD (SIMD<float,2> v0, SIMD<float,2> v1) : data{_mm_movelh_ps(v0.Data(), v1.Data())} { }
    SIMD (std::array<float, 4> arr) : SIMD(arr[0], arr[1], arr[2], arr[3]) { }

    SIMD & operator= (const SIMD &) = default;

    SIMD (float val)  : data{_mm_set1_ps(val)} { }
    SIMD (double val) : SIMD(float(val)) { }
    SIMD (int val)    : SIMD(float(val)) { }
    SIMD (size_t val) : SIMD(float(val)) { }

    SIMD (float const * p) : data{_mm_loadu_ps(p)} { }

    SIMD (__m128 _data) : data{_data} { }

    template<typename T, typename std::enable_if<std::is_convertible<T, std::function<float(int)>>::value, int>::type = 0>
    SIMD (const T & func)
    {
      data = _mm_setr_ps(func(0), func(1), func(2), func(3));
    }

    void Store (float * p) { _mm_storeu_ps(p, data); }

    NETGEN_INLINE float operator[] (int i) const { return ((float*)(&data))[i]; }
    NETGEN_INLINE float & operator[] (int i) { return ((float*)(&data))[i]; }

    template <int I>
    float Get() const
    {
      static_assert(I>=0 && I<4, "Index out of range");
      return (*this)[I];
    }

    NETGEN_INLINE __m128 Data() const { return data; }
    NETGEN_INLINE __m128 & Data() { return data; }

    SIMD<float,2> Lo() const { return data; }
    SIMD<float,2> Hi() const { return _mm_movehl_ps(data, data); }
  };

  NETGEN_INLINE SIMD<float,4> operator- (SIMD<float,4> a) { return _mm_xor_ps(a.Data(), _mm_set1_ps(-0.0f)); }
  NETGEN_INLINE SIMD<float,4> operator+ (SIMD<float,4> a, SIMD<float,4> b) { return _mm_add_ps(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<float,4> operator- (SIMD<float,4> a, SIMD<float,4> b) { return _mm_sub_ps(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<float,4> operator* (SIMD<float,4> a, SIMD<float,4> b) { return _mm_mul_ps(a.Data(),b.Data()); }
  NETGEN_INLINE SIMD<float,4> operator/ (SIMD<float,4> a, SIMD<float,4> b) { return _mm_div_ps(a.Data(),b.Data()); }

  NETGEN_INLINE float HSum (SIMD<float,4> a)
  {
    __m128 t = _mm_add_ps(a.Data(), _mm_movehl_ps(a.Data(), a.Data()));
    t = _mm_add_ss(t, _mm_shuffle_ps(t, t, 1));
    return _mm_cvtss_f32(t);
  }

  NETGEN_INLINE SIMD<float,4> FMA (SIMD<float,4> a, SIMD<float,4> b, SIMD<float,4> c)
  {
#ifdef __FMA__
    return _mm_fmadd_ps(a.Data(), b.Data(), c.Data());
#else
    return a*b+c;
#endif
  }

  NETGEN_INLINE SIMD<float,4> FMA (const float & a, SIMD<float,4> b, SIMD<float,4> c)
  {
    return FMA(SIMD<float,4> (a), b, c);
  }

  NETGEN_INLINE SIMD<float,2> fabs (SIMD<float,2> a) { return _mm_max_ps(a.Data(), (-a).Data()); }
  NETGEN_INLINE SIMD<float,4> fabs (SIMD<float,4> a) { return _mm_max_ps(a.Data(), (-a).Data()); }

  NETGEN_INLINE SIMD<float,2> Min (SIMD<float,2> a, SIMD<float,2> b) { return _mm_min_ps(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<float,4> Min (SIMD<float,4> a, SIMD<float,4> b) { return _mm_min_ps(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<float,2> Max (SIMD<float,2> a, SIMD<float,2> b) { return _mm_max_ps(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<float,4> Max (SIMD<float,4> a, SIMD<float,4> b) { return _mm_max_ps(a.Data(), b.Data()); }

#ifdef __SSE4_1__
  NETGEN_INLINE SIMD<float,2> round (SIMD<float,2> a)
  { return _mm_round_ps(a.Data(), _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC); }
  NETGEN_INLINE SIMD<float,4> round (SIMD<float,4> a)
  { return _mm_round_ps(a.Data(), _MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC); }
#endif


  // *************************** mask32 ***************************

  template <>
  class SIMD<mask32,2>
  {
    __m128i mask;
  public:
    SIMD (int i)
      : mask(_mm_cmpgt_epi32(_mm_set1_epi32(i),
                             _mm_set_epi32(3, 2, 1, 0)))
    { ; }
    SIMD (bool i0, bool i1) { mask = _mm_set_epi32(0, 0, i1?-1:0, i0?-1:0); }
    SIMD (SIMD<mask32,1> i0, SIMD<mask32,1> i1) : SIMD(bool(i0[0]), bool(i1[0])) { ; }
    SIMD (__m128i _mask) : mask(_mask) { ; }
    __m128i Data() const { return mask; }
    static constexpr int Size() { return 2; }
  };

  template <>
  class SIMD<mask32,4>
  {
    __m128i mask;
  public:
    SIMD (int i)
      : mask(_mm_cmpgt_epi32(_mm_set1_epi32(i),
                             _mm_set_epi32(3, 2, 1, 0)))
    { ; }
    SIMD (bool i0, bool i1, bool i2, bool i3)
    { mask = _mm_set_epi32(i3?-1:0, i2?-1:0, i1?-1:0, i0?-1:0); }
    SIMD (SIMD<mask32,2> lo, SIMD<mask32,2> hi)
    { mask = _mm_unpacklo_epi64(lo.Data(), hi.Data()); }
    SIMD (__m128i _mask) : mask(_mask) { ; }
    __m128i Data() const { return mask; }
    static constexpr int Size() { return 4; }

    SIMD<mask32,2> Lo() const { return mask; }
    SIMD<mask32,2> Hi() const { return _mm_unpackhi_epi64(mask, mask); }
  };


  // *************************** int32 ***************************

  // stored in the lower half of an xmm register, upper lanes are undefined
  template<>
  class alignas(16) SIMD<int32_t,2>
  {
    __m128i data;

  public:
    static constexpr int Size() { return 2; }
    SIMD () {}
    SIMD (const SIMD &) = default;
    SIMD & operator= (const SIMD &) = default;

    SIMD (int32_t val) : data{_mm_set1_epi32(val)} { }
    SIMD (size_t val)  : SIMD(int32_t(val)) { }
    SIMD (int32_t v0, int32_t v1) : data{_mm_set_epi32(0, 0, v1, v0)} { }
    SIMD (SIMD<int32_t,1> v0, SIMD<int32_t,1> v1) : SIMD(v0.Data(), v1.Data()) { }
    SIMD (std::array<int32_t,2> arr) : SIMD(arr[0], arr[1]) { }
    SIMD (int32_t const * p) : data{_mm_loadl_epi64((__m128i const*)p)} { }
    SIMD (__m128i _data) : data{_data} { }

    NETGEN_INLINE auto operator[] (int i) const { return ((int32_t*)(&data))[i]; }
    NETGEN_INLINE int32_t & operator[] (int i) { return ((int32_t*)(&data))[i]; }
    NETGEN_INLINE __m128i Data() const { return data; }
    NETGEN_INLINE __m128i & Data() { return data; }

    void Store (int32_t * p) { _mm_storel_epi64((__m128i*)p, data); }

    SIMD<int32_t,1> Lo() const { return (*this)[0]; }
    SIMD<int32_t,1> Hi() const { return (*this)[1]; }
    static SIMD FirstInt(int32_t n0=0) { return { n0, n0+1 }; }
  };

  template<>
  class alignas(16) SIMD<int32_t,4>
  {
    __m128i data;

  public:
    static constexpr int Size() { return 4; }
    SIMD () {}
    SIMD (const SIMD &) = default;
    SIMD & operator= (const SIMD &) = default;

    SIMD (int32_t val) : data{_mm_set1_epi32(val)} { }
    SIMD (size_t val)  : SIMD(int32_t(val)) { }
    SIMD (int32_t v0, int32_t v1, int32_t v2, int32_t v3) : data{_mm_set_epi32(v3, v2, v1, v0)} { }
    SIMD (SIMD<int32_t,2> lo, SIMD<int32_t,2> hi) : data{_mm_unpacklo_epi64(lo.Data(), hi.Data())} { }
    SIMD (std::array<int32_t,4> arr) : SIMD(arr[0], arr[1], arr[2], arr[3]) { }
    SIMD (int32_t const * p) : data{_mm_loadu_si128((__m128i const*)p)} { }
    SIMD (__m128i _data) : data{_data} { }

    NETGEN_INLINE auto operator[] (int i) const { return ((int32_t*)(&data))[i]; }
    NETGEN_INLINE int32_t & operator[] (int i) { return ((int32_t*)(&data))[i]; }
    NETGEN_INLINE __m128i Data() const { return data; }
    NETGEN_INLINE __m128i & Data() { return data; }

    void Store (int32_t * p) { _mm_storeu_si128((__m128i*)p, data); }

    SIMD<int32_t,2> Lo() const { return data; }
    SIMD<int32_t,2> Hi() const { return _mm_unpackhi_epi64(data, data); }
    static SIMD FirstInt(int32_t n0=0) { return { n0, n0+1, n0+2, n0+3 }; }
  };

  NETGEN_INLINE SIMD<int32_t,2> operator+ (SIMD<int32_t,2> a, SIMD<int32_t,2> b) { return _mm_add_epi32(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<int32_t,4> operator+ (SIMD<int32_t,4> a, SIMD<int32_t,4> b) { return _mm_add_epi32(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<int32_t,2> operator- (SIMD<int32_t,2> a, SIMD<int32_t,2> b) { return _mm_sub_epi32(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<int32_t,4> operator- (SIMD<int32_t,4> a, SIMD<int32_t,4> b) { return _mm_sub_epi32(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<int32_t,2> operator& (SIMD<int32_t,2> a, SIMD<int32_t,2> b) { return _mm_and_si128(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<int32_t,4> operator& (SIMD<int32_t,4> a, SIMD<int32_t,4> b) { return _mm_and_si128(a.Data(), b.Data()); }

  template <int N>
  SIMD<int32_t,2> operator<< (SIMD<int32_t,2> a, IC<N> n) { return _mm_slli_epi32(a.Data(), N); }
  template <int N>
  SIMD<int32_t,4> operator<< (SIMD<int32_t,4> a, IC<N> n) { return _mm_slli_epi32(a.Data(), N); }

  NETGEN_INLINE SIMD<mask32,2> operator== (SIMD<int32_t,2> a, SIMD<int32_t,2> b) { return _mm_cmpeq_epi32(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<mask32,4> operator== (SIMD<int32_t,4> a, SIMD<int32_t,4> b) { return _mm_cmpeq_epi32(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<mask32,2> operator> (SIMD<int32_t,2> a, SIMD<int32_t,2> b) { return _mm_cmpgt_epi32(a.Data(), b.Data()); }
  NETGEN_INLINE SIMD<mask32,4> operator> (SIMD<int32_t,4> a, SIMD<int32_t,4> b) { return _mm_cmpgt_epi32(a.Data(), b.Data()); }

  NETGEN_INLINE __m128i my_mm_select_si128 (__m128i mask, __m128i b, __m128i c)
  {
    return _mm_or_si128(_mm_andnot_si128(mask, c), _mm_and_si128(mask, b));
  }

  NETGEN_INLINE SIMD<int32_t,2> If (SIMD<mask32,2> a, SIMD<int32_t,2> b, SIMD<int32_t,2> c)
  { return my_mm_select_si128(a.Data(), b.Data(), c.Data()); }
  NETGEN_INLINE SIMD<int32_t,4> If (SIMD<mask32,4> a, SIMD<int32_t,4> b, SIMD<int32_t,4> c)
  { return my_mm_select_si128(a.Data(), b.Data(), c.Data()); }

#ifdef __SSE4_1__
  NETGEN_INLINE SIMD<float,2> If (SIMD<mask32,2> a, SIMD<float,2> b, SIMD<float,2> c)
  { return _mm_blendv_ps(c.Data(), b.Data(), _mm_castsi128_ps(a.Data())); }
  NETGEN_INLINE SIMD<float,4> If (SIMD<mask32,4> a, SIMD<float,4> b, SIMD<float,4> c)
  { return _mm_blendv_ps(c.Data(), b.Data(), _mm_castsi128_ps(a.Data())); }
#else
  NETGEN_INLINE SIMD<float,2> If (SIMD<mask32,2> a, SIMD<float,2> b, SIMD<float,2> c)
  { return _mm_castsi128_ps(my_mm_select_si128(a.Data(), _mm_castps_si128(b.Data()), _mm_castps_si128(c.Data()))); }
  NETGEN_INLINE SIMD<float,4> If (SIMD<mask32,4> a, SIMD<float,4> b, SIMD<float,4> c)
  { return _mm_castsi128_ps(my_mm_select_si128(a.Data(), _mm_castps_si128(b.Data()), _mm_castps_si128(c.Data()))); }
#endif

  NETGEN_INLINE SIMD<int32_t,2> lround (SIMD<float,2> a) { return _mm_cvtps_epi32(a.Data()); }
  NETGEN_INLINE SIMD<int32_t,4> lround (SIMD<float,4> a) { return _mm_cvtps_epi32(a.Data()); }

  template <>
  NETGEN_INLINE SIMD<float,2> Reinterpret (SIMD<int32_t,2> a) { return _mm_castsi128_ps(a.Data()); }
  template <>
  NETGEN_INLINE SIMD<float,4> Reinterpret (SIMD<int32_t,4> a) { return _mm_castsi128_ps(a.Data()); }


  // same semantics as the generic Unpack: interleave within each Lo/Hi half
  // (a0,b0,a2,b2), (a1,b1,a3,b3)
  template<>
  NETGEN_INLINE auto Unpack (SIMD<float,4> a, SIMD<float,4> b)
  {
    __m128 lo = _mm_unpacklo_ps(a.Data(), b.Data());
    __m128 hi = _mm_unpackhi_ps(a.Data(), b.Data());
    return std::make_tuple(SIMD<float,4>(_mm_shuffle_ps(lo, hi, _MM_SHUFFLE(1,0,1,0))),
                           SIMD<float,4>(_mm_shuffle_ps(lo, hi, _MM_SHUFFLE(3,2,3,2))));
  }

  template<>
  NETGEN_INLINE SIMD<float,4> SwapPairs (SIMD<float,4> a)
  {
    return _mm_shuffle_ps(a.Data(), a.Data(), _MM_SHUFFLE(2,3,0,1));
  }

}

#endif // NETGEN_CORE_SIMD_SSE_HPP
