# Rebuild the Cubit command plugin

Use your own Coreform Cubit 2026.8 installation and its SDK. Set up a Visual
Studio 2022 x64 developer environment with MSVC 14.44.35207, CMake and Ninja.
Run these commands from the extracted archive. Replace the example Cubit
path with the directory containing your installed CubitConfig.cmake.

    cmake -S src/cubit_plugin -B build-ccm -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCubit_DIR=C:/Program Files/Coreform Cubit 2026.8/cmake"
    cmake --build build-ccm --target cubit_mesh_export_ccm --parallel 2

The result is build-ccm/cubit_mesh_export.ccm. To relink with changes, modify
the Compact Netgen sources in src/cubit_plugin/compact_netgen and repeat the
commands with a fresh build directory. Use an isolated Cubit plugin directory
to load and test your modified plugin.
